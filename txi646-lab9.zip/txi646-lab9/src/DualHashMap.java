import java.util.*;
public class DualHashMap<K,V> implements DualMap<K,V> {

		private Map<K,V> mp1;
		private Map<V,K> mp2;
		
		public DualHashMap() {
			mp1 = new HashMap<K,V>();
			mp2 = new HashMap<V,K>();
	}

		@Override
		public void put(K key, V value) {
			this.mp1.put(key, value);
			this.mp2.put(value,key);
			
		}

		@Override
		public void remove(K key, V value) {
			this.mp1.remove(key, value);
			this.mp2.remove(value,key);
		}

		@Override
		public V get(K key) {
			return this.mp1.get(key);
		}

		@Override
		public K reverseGet(V value) {
				return this.mp2.get(value);
		}
		

}
