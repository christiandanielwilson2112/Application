package lab3;

//class DateRange: contains functions called in main
public class DateRange {
	Date current;
	Date next;

	//DateRange: DateRange object, initializes current and next
	public DateRange(Date a, Date b) {
		this.current = a;
		this.next = b;
	}

	//toString: returns DateRange parsed out
	public String toString() {
		return "DateRange: " + current + " - " + next;
	}

}
