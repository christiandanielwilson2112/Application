package lab3;
/**********************************
 * 
 * @author Christian Wilson
 * 
 **********************************/

import java.util.Scanner;
import java.io.*;

//class Lab3: contains main
public class Lab3 {

	// main: program starts here
	public static void main(String[] args) {

		Scanner in = null;
		try {
			in = new Scanner(new File("dates.txt"));
		} catch (FileNotFoundException exception) {
			System.err.println("failed to open dates.txt");
			System.exit(1);
		}

		boolean run;

		while (in.hasNextLine()) {
			String line = in.nextLine();
			Date date = new Date(line);
			date.ParseDate();
			date.MonthConvert();
			date.DayValid();

			if (date.month.compareTo("Invalid date.") == 0) {
				System.out.println("Invalid date.");
				run = false;
			} else {
				System.out.println(date);
				run = true;
			}

			if (run == true) {
				while (in.hasNextLine() && run == true) {
					String line2 = in.nextLine();
					Date other = new Date(line2);
					other.ParseDate();
					other.MonthConvert();
					other.DayValid();
					if (other.month.compareTo("Invalid date.") == 0) {
						System.out.println("Invalid date.");
					} else {
						System.out.println(other);
						DateRange daterange = new DateRange(date, other);
						int n = date.compareTo(other);
						if (n == 1) {
							System.out.println(daterange);
						} else if (n == -1) {
							run = false;
						}
					}
				}
			}
		}
		in.close();
	}
}
