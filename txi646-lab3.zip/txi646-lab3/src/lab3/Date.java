package lab3;

//class Date: contains functions called in main
public class Date {
	public String date;
	public String other;
	public String month;
	public int day;
	public int year;

	//Date: Date object, initializes month, day, and year
	public Date(String a) {
		this.month = a;
		this.day = 0;
		this.year = 0;
	}

	//ParseDate: separates each line into month, day, and year
	public void ParseDate() {
		char c = ' ';
		char b = ' ';
		int i;
		String str = " ";
		String str2 = " ";
		for (i = 0; i < this.month.length() - 1; i++) {
			c = this.month.charAt(i);
			if (c >= '0' && c <= '9') {
				break;
			}
		}
		b = this.month.charAt(i + 1);
		if (b >= '0' && b <= '9') {
			str = this.month.substring(i, i + 2);
		} else {
			str = this.month.substring(i, i + 1);
		}
		str2 = this.month.substring(this.month.length() - 4, this.month.length());
		this.month = this.month.substring(0, 3);
		this.day = Integer.parseInt(str);
		this.year = Integer.parseInt(str2);
	}

	//MonthConvert: converts abbreviated month to full month name
	public void MonthConvert() {
		if (this.month.compareTo("Jan") == 0) {
			this.month = "January";
		} else if (this.month.compareTo("Feb") == 0) {
			this.month = "February";
		} else if (this.month.compareTo("Mar") == 0) {
			this.month = "March";
		} else if (this.month.compareTo("Apr") == 0) {
			this.month = "April";
		} else if (this.month.compareTo("Jun") == 0) {
			this.month = "June";
		} else if (this.month.compareTo("Jul") == 0) {
			this.month = "July";
		} else if (this.month.compareTo("Aug") == 0) {
			this.month = "August";
		} else if (this.month.compareTo("Sep") == 0) {
			this.month = "September";
		} else if (this.month.compareTo("Oct") == 0) {
			this.month = "October";
		} else if (this.month.compareTo("Nov") == 0) {
			this.month = "November";
		} else if (this.month.compareTo("Dec") == 0) {
			this.month = "December";
		} else {
			return;
		}
	}

	//DayValid: checks if the month and day are compatible
	public void DayValid() {
		if (this.day >= 28) {
			if (this.month == "February" && this.day >= 29) {
				this.month = "Invalid date.";
			} else if (this.month == "June" && this.day >= 31) {
				this.month = "Invalid date.";
			} else if (this.month == "April" && this.day >= 31) {
				this.month = "Invalid date.";
			} else if (this.month == "November" && this.day >= 31) {
				this.month = "Invalid date.";
			} else if (this.month == "September" && this.day >= 31) {
				this.month = "Invalid date.";
			}
		}
	}

	//compareTo: compares the dates and returns 0 if this and other are same,
	//1 if other is after this 
	//-1 if this is after other
	public int compareTo(Date other) {
		int num = 0;
		int num2 = 0;
		if (other.month.compareTo("January") == 0) {
			num2 = 1;
		} else if (other.month.compareTo("February") == 0) {
			num2 = 2;
		} else if (other.month.compareTo("March") == 0) {
			num2 = 3;
		} else if (other.month.compareTo("April") == 0) {
			num2 = 4;
		} else if (other.month.compareTo("May") == 0) {
			num2 = 5;
		} else if (other.month.compareTo("June") == 0) {
			num2 = 6;
			;
		} else if (other.month.compareTo("July") == 0) {
			num2 = 7;
		} else if (other.month.compareTo("August") == 0) {
			num2 = 8;
		} else if (other.month.compareTo("September") == 0) {
			num2 = 9;
		} else if (other.month.compareTo("October") == 0) {
			num2 = 10;
		} else if (other.month.compareTo("November") == 0) {
			num2 = 11;
		} else if (other.month.compareTo("December") == 0) {
			num2 = 12;
		}

		if (this.month.compareTo("January") == 0) {
			num = 1;
		} else if (this.month.compareTo("February") == 0) {
			num = 2;
		} else if (this.month.compareTo("March") == 0) {
			num = 3;
		} else if (this.month.compareTo("April") == 0) {
			num = 4;
		} else if (this.month.compareTo("May") == 0) {
			num = 5;
		} else if (this.month.compareTo("June") == 0) {
			num = 6;
		} else if (this.month.compareTo("July") == 0) {
			num = 7;
		} else if (this.month.compareTo("August") == 0) {
			num = 8;
		} else if (this.month.compareTo("September") == 0) {
			num = 9;
		} else if (this.month.compareTo("October") == 0) {
			num = 10;
		} else if (this.month.compareTo("November") == 0) {
			num = 11;
		} else if (this.month.compareTo("December") == 0) {
			num = 12;
		}

		if (other.year < this.year) {
			return -1;
		} else if (this.year == other.year) {
			if (num2 > num || (num == num2 && other.day > this.day))
				return 1;
			else
				return 0;
		} else {
			return 1;
		}
	}

	//toString: returns string of date parsed out
	public String toString() {
		return "Date: " + month + " " + day + ", " + year;
	}

}
