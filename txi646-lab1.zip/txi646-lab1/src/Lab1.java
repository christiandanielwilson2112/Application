
/*********************************** 
 * @author Christian Wilson 
 ***********************************/

import java.util.Scanner;
import java.io.File;

//Class Lab1: contains main method
public class Lab1 {

	// main: scans tokens from file and prints number of numbers, number of non
	// numbers, and sum of the numbers
	public static void main(String[] args) {

		Scanner in = null;
		
		int nums = 0;
		int nonnums = 0;
		double sum = 0;
		
		try {
			in = new Scanner(new File("data.txt"));
		} catch (Exception FileNotFoundException) {
			System.err.println("failed to open data.txt");
			System.exit(1);
		}

		while (in.hasNext()) {
		    String token = in.next();
	
		    if (new Scanner(token).hasNextDouble()) {
		        double d = Double.parseDouble(token);
		        nums++;
		        sum+=d;
		    } else {
		        nonnums++;
		    }
		}
		
		in.close();
		System.out.printf("%d %d %.1f", nums, nonnums, sum);
	}

}
