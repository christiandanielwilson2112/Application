import java.awt.event.*;

public class PanelSwitcherController implements ActionListener{

	private PanelSwitcherView view;
	private PanelSwitcherModel model;
	
	/**
	 * constructor
	 * @param view
	 * @param model
	 */
	public PanelSwitcherController(PanelSwitcherView view, PanelSwitcherModel model) {
		this.view = view;
		this.model = model;
	}
	
	/**
	 * returns current model
	 * @return
	 */
	public PanelSwitcherModel getModel(){
		return this.model;
	}
	
	/**
	 * handles jbutton interaction
	 */
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if(command.equals("Switch Panels")) {
			model.switchPanel();
			view.displayPanel(model.whichPanel());
		}
	}

}
