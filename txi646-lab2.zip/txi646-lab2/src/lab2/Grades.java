package lab2;

//Public class Grades: contains functions called in Lab2.java
public class Grades {
	public int[] gradeArray = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	public String name;

	// Grades: initializes name
	public Grades() {
		name = "name";
	}

	// Grades: initializes name and gradeArray
	public Grades(String name, int[] gradeArray) {
		this.name = name;
		this.gradeArray = gradeArray;
	}

	// getName: returns name
	public String getName(Grades a) {
		return a.name;
	}

	// length: returns the length of the gradeArray
	public int length(Grades a) {
		int i = 1;
		int length = 0;
		while (i != 0) {
			i = a.gradeArray[length];
			length++;
		}
		return length - 1;
	}

	// average: returns mean of the grades
	public double average(Grades a) {
		double avg = 0.0;
		int length = length(a);
		for (int i = 0; i < length; i++) {
			avg += a.gradeArray[i];
		}
		avg /= length;
		return avg;
	}

	// median: returns median of grades
	public double median(Grades a) {
		int i, j, first, temp;
		int length = length(a);
		double median = 0.0;
		for (i = length - 1; i > 0; i--) {
			first = 0;
			for (j = 1; j <= i; j++) {
				if (a.gradeArray[j] < a.gradeArray[first])
					first = j;
			}
			temp = a.gradeArray[first];
			a.gradeArray[first] = a.gradeArray[i];
			a.gradeArray[i] = temp;
		}
		if (length % 2 != 0) {
			length = length / 2;
			median = (double) a.gradeArray[length];
		} else {
			median = (double) (a.gradeArray[length / 2 - 1] + a.gradeArray[length / 2]) / 2;
		}
		return median;
	}

	// maximum: returns highest grade
	public int maximum(Grades a) {
		int max = 0;
		int length = length(a);
		for (int i = 0; i < length; i++) {
			if (a.gradeArray[i] > max)
				max = a.gradeArray[i];
		}
		return max;
	}

	// minimum: returns lowest grade
	public int minimum(Grades a) {
		int min = 100;
		int length = length(a);
		for (int i = 0; i < length; i++) {
			if (a.gradeArray[i] != 0) {
				if (a.gradeArray[i] < min) {
					min = a.gradeArray[i];
				}
			}
		}
		return min;
	}

	// toString: prints a space
	@Override
	public String toString() {
		return " ";
	}
}
