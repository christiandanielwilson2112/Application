package lab2;
/**********************************************
 * 
 * @author Christian Wilson
 * 
 ***********************************************/

import java.util.Scanner;
import java.io.*;

//Class Lab2: contains main method
public class Lab2 {

	// main: reads data from file, puts that data into an array, sends it to be
	// processed, and resets array
	public static void main(String[] args) {
		Scanner in = null;
		Grades a = new Grades();
		int i = 0;

		try {
			in = new Scanner(new File("data.txt"));
		} catch (FileNotFoundException exception) {
			System.err.println("failed to open data.txt");
			System.exit(1);
		}
		while (in.hasNext()) {
			String name = in.next();
			a.name = name;
			while (in.hasNextInt()) {
				int grade = in.nextInt();
				a.gradeArray[i] = grade;
				i++;
			}
			System.out.print(a.name + " [");
			for (i = 0; i < a.length(a); i++) {
				System.out.print(a.gradeArray[i] + ", ");
			}
			System.out.print("]");
			testGrades(a);
			for (i = 0; i < 19; i++) {
				a.gradeArray[i] = 0;
			}
			i = 0;
		}
	}

	// testGrades: processes the data with function calls
	public static void testGrades(Grades grades) {
		System.out.println(grades.toString());
		System.out.printf("\tName:    %s\n", grades.getName(grades));
		System.out.printf("\tLength:  %d\n", grades.length(grades));
		System.out.printf("\tAverage: %.2f\n", grades.average(grades));
		System.out.printf("\tMedian:  %.1f\n", grades.median(grades));
		System.out.printf("\tMaximum: %d\n", grades.maximum(grades));
		System.out.printf("\tMininum: %d\n", grades.minimum(grades));
	}
}
