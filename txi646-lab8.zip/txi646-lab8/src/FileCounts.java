import java.io.*;
import java.util.*;

public class FileCounts {
    private File file;
    
    public FileCounts(File file) {
        this.file = file;
    }
 
    public int lineCount() throws FileNotFoundException{
    	int lineCount = 0;
    	Scanner lineFile = new Scanner(file);
    	while(lineFile.hasNext()) {
    		if(lineFile.nextLine() != null) {
    			lineCount++;
    		}
    	}
    	lineFile.close();
        return lineCount;
    }
    
    public int tokenCount() throws FileNotFoundException{
    	int tokenCount = 0;
    	Scanner tokenFile = new Scanner(file);
    	while(tokenFile.hasNext()) {
    		if(tokenFile.next() != null) {
    		tokenCount++;
    		}
    	}
    	tokenFile.close();
        return tokenCount;
    }
    
    public int charCount() throws IOException{
    	int charCount = 0;
    	FileReader charReader = new FileReader(file);
    	BufferedReader charBuf = new BufferedReader(charReader);
    	while(charBuf.read() != -1) {
    		charCount++;
    	}
    	charBuf.close();
    	charReader.close();
        return charCount;
    }
    
    public int byteCount() throws IOException{
    	int byteCount = 0;
    	FileInputStream byteReader = new FileInputStream(file);
    	BufferedInputStream byteBuf =  new BufferedInputStream(byteReader);
    	while(byteBuf.read() != -1) {
    		byteCount++;
    	}
    	byteBuf.close();
    	byteReader.close();
        return byteCount;
    }
}
