package length;

//Class Inch: extends Length, contains add, getUnit, toMeters methods
public class Inch extends Length{

	double length;

	/**
	 * 1 inch = 0.0254 meters
	 */
	public static final double METERS_PER_INCH = 0.0254;

	//Inch: uses superclass length and creates Inch object
	public Inch(double length) {
		super(length);
		this.length = length;
	}

	/**
	 * This should add the other Length to this Length object.
	 * 
	 * @param other
	 */
	@Override
	public void add(Length other) {
	    this.setLength(this.length += other.toMeters() / METERS_PER_INCH);
	}

	/**
	 * This should return a different String if the length is exactly 1.0.
	 * 
	 * @return the correct name of the unit of this Length object.
	 */
	@Override
	public String getUnit() {
		if (this.length == 1.0)
			return "inch";
		return "inches";
	}

	/**
	 * @return the length in meters
	 */
	@Override
	public double toMeters() {
		return this.length * METERS_PER_INCH;
	}

}
