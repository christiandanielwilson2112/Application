package length;

//Class Meter: extends Length, contains add, getUnit, toMeters methods
public class Meter extends Length {

	double length;

	//Meter: uses superclass length and creates Meter object
	public Meter(double length) {
		super(length);
		this.length = length;
	}

	/**
	 * This should add the other Length to this Length object.
	 * 
	 * @param other
	 */
	@Override
	public void add(Length other) {
		this.setLength(this.length += other.toMeters());
	}

	/**
	 * This should return a different String if the length is exactly 1.0.
	 * 
	 * @return the correct name of the unit of this Length object.
	 */
	@Override
	public String getUnit() {
		if (this.length == 1.0)
			return "meter";
		return "meters";
	}

	/**
	 * @return the length in meters
	 */
	@Override
	public double toMeters() {
		return this.length;
	}
}
