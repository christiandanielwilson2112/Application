package length;

/**********************************
 * 
 * @author Christian Wilson
 * 
 **********************************/

import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

//Class Lab4: contains main, maximum, minimum, sum1, sum2 methods
public class Lab4 {

	//main: program starts here
	public static void main(String[] args) {

		Scanner in = null;
		ArrayList<Length> list = new ArrayList<Length>();
		Meter length = null;
		Inch length2 = null;
		Foot length3 = null;
		Yard length4 = null;
		int i = 0;
		try {
			in = new Scanner(new File("data.txt"));
		} catch (FileNotFoundException exception) {
			throw new RuntimeException("failed to open data.txt");
		}

		while (in.hasNextDouble()) {
			double value = in.nextDouble();
			String unit = in.next();
			// code here to use the value of unit to create the
			// right type of Length object and store it in length.
			if (unit.compareTo("meter") == 0 || unit.compareTo("meters") == 0) {
				length = new Meter(value);
				list.add(length);
			} else if (unit.compareTo("inch") == 0 || unit.compareTo("inches") == 0) {
				length2 = new Inch(value);
				list.add(length2);
			} else if (unit.compareTo("foot") == 0 || unit.compareTo("feet") == 0) {
				length3 = new Foot(value);
				list.add(length3);
			} else if (unit.compareTo("yard") == 0 || unit.compareTo("yards") == 0) {
				length4 = new Yard(value);
				list.add(length4);
			}

			System.out.println(list.get(i));
			i++;

		}
		System.out.println();
		minimum(list);
		maximum(list);
		sum1(list);
		sum2(list);

		in.close();
	}

	// maximum: returns largest length
	public static void maximum(ArrayList<Length> a) {
		double max = 0;
		int length = a.size() - 1;
		int i;
		int index = 0;
		for (i = 0; i < length; i++) {
			if (a.get(i).getLength() > max && a.get(i).compareTo(a.get(index)) == 1) {
				max = a.get(i).getLength();
				index = i;
			}
		}
		System.out.println("Maximum is " + a.get(index).getClass() + ": " + a.get(index).getLength() + " "
				+ a.get(index).getUnit());

	}

	// minimum: returns smallest length
	public static void minimum(ArrayList<Length> a) {
		double min = 1000000000;
		int length = a.size() - 1;
		int i;
		int index = 0;
		for (i = 0; i < length; i++) {
			if (a.get(i).getLength() < min && a.get(i).compareTo(a.get(index)) == -1) {
				min = a.get(i).getLength();
				index = i;
			}
		}
		System.out.println("Minimum is " + a.get(index).getClass() + ": " + a.get(index).getLength() + " "
				+ a.get(index).getUnit());
	}

	//sum1: sums all lengths from first to last and prints them in each unit
	public static void sum1(ArrayList<Length> list) {
		System.out.println("\nSum of Lengths Adding from First to Last");
		Meter meter = new Meter(0.0);
		Inch inch = new Inch(0.0);
		Foot foot = new Foot(0.0);
		Yard yard = new Yard(0.0);
		for (int i = 0; i <= list.size() - 1; i++) {
			meter.add(list.get(i));
			inch.add(list.get(i));
			foot.add(list.get(i));
			yard.add(list.get(i));
		}
		System.out.println(meter);
		System.out.println(inch);
		System.out.println(foot);
		System.out.println(yard);
	}

	//sum2: sums all lengths from last to first and prints them in each unit
	public static void sum2(ArrayList<Length> list) {
		System.out.println("\nSum of Lengths Adding from Last to First");
		Meter meter = new Meter(0.0);
		Inch inch = new Inch(0.0);
		Foot foot = new Foot(0.0);
		Yard yard = new Yard(0.0);
		for (int i = list.size() - 1; i >= 0; i--) {
			meter.add(list.get(i));
			inch.add(list.get(i));
			foot.add(list.get(i));
			yard.add(list.get(i));
		}
		System.out.println(meter);
		System.out.println(inch);
		System.out.println(foot);
		System.out.println(yard);
	}

}
