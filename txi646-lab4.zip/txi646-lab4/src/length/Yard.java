package length;

//Class Yard: extends Length, contains add, getUnit, toMeters methods
public class Yard extends Length {

	double length;

	/**
	 * 1 yard = 0.9144 meters
	 */
	public static final double METERS_PER_YARD = 0.9144;

	//Yard: uses superclass length and creates Yard object
	public Yard(double length) {
		super(length);
		this.length = length;
	}

	/**
	 * This should add the other Length to this Length object.
	 * 
	 * @param other
	 */
	@Override
	public void add(Length other) {
		this.setLength(this.length += other.toMeters() / METERS_PER_YARD);
	}

	/**
	 * This should return a different String if the length is exactly 1.0.
	 * 
	 * @return the correct name of the unit of this Length object.
	 */
	@Override
	public String getUnit() {
		if (this.length == 1.0)
			return "yard";
		return "yards";
	}

	/**
	 * @return the length in meters
	 */
	@Override
	public double toMeters() {
		return this.length * METERS_PER_YARD;
	}

}
